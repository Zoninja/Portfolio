// ==========================================
// Escape the Woods - A Spooky Adventure Game
// ==========================================

let room = 0;
let message = "";
let hasFlashlight = false;
let hasKey = false;
let hasBlessing = false;
let hasCoffee = false;
let exorcism = false 
let carImg;
let outsideCarImg;
let trunkImg;
let gasImg;
let pathImg;
let pathCabinImg;
let cabinImg;
let roomGirlImg;
let roomEmptyImg;
let possessedImg;
let manImg;
let winImg;
let music;
let deadSound;
let cryingSound;
let laughSound;
let laugh2Sound;
let winSound;

async function setup() {
  createCanvas(800, 800);
  textAlign(CENTER, CENTER);

  // Load images
  
  loadImage("car.png", function (img) {
    carImg = img;
  });
  
  loadImage("outsidecar.png", function (img) {
    outsideCarImg = img;
  });
  
    loadImage("trunk.png", function (img) {
    trunkImg = img;
  });
  
    loadImage("gas.png", function (img) {
    gasImg = img;
  });
  
    loadImage("path.png", function (img) {
    pathImg = img;
  });
  
      loadImage("path-cabin.png", function (img) {
    pathCabinImg = img;
  });

      loadImage("cabin.png", function (img) {
    cabinImg = img;
  });

  loadImage("room-girl.png", function (img) {
    roomGirlImg = img;
  });

  loadImage("room-empty.png", function (img) {
    roomEmptyImg = img;
  });

  loadImage("possessed.png", function (img) {
    possessedImg = img;
  });

  loadImage("man.png", function (img) {
    manImg = img;
  });
  
  loadImage("win.png", function (img) {
    winImg = img;
  });
  music = createAudio("spooky.mp3");
  music.volume(0.3);
  deadSound = createAudio("dead.mp3");
  deadSound.volume(0.2);
  cryingSound = createAudio("crying.mp3");
  cryingSound.volume(0.1);
  laughSound = createAudio("laugh.mp3");
  laughSound.volume(0.1);
  laugh2Sound = createAudio("laugh-2.mp3");
  laugh2Sound.volume(0.1);
  winSound = createAudio("success.mp3");

}

function draw() {

  // ==========================================
  // ROOM 0 - START
  // ==========================================

  if (room === 0) {
    if (carImg) {
      image(carImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    }
    textPanel();
    fill(250);
    textSize(19);
    text("It's 2:45 a.m. and you're driving through a back road you've never taken. \nAll of a sudden your car starts to sputter. \n \n*putt-putt-putt-putt-pfft*", 400, 600);
    hintText("(left-click to continue)");
  }

  // ==========================================
  // ROOM 1 - THE BREAKDOWN
  // ==========================================

  if (room === 1) {
    (carImg) 
      image(carImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    
    storyText("Your car jerks and the engine dies.\n\n You check your phone. No cell signal. A sign beside you reads:\n\n GENEVA - 13 MILES \n \n You decide to step out to check the engine.");
    hintText("(left-click to exit the car)");
  }

  // ==========================================
  // ROOM 2 - OUTSIDE THE CAR
  // ==========================================

  if (room === 2) {
   (outsideCarImg) 
      image(outsideCarImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    
    storyText("You check the engine but you have no idea what's happened.\n \n Trees and darkness surround you. Further up the road you see a dim light. To your left, a dirt path leads into the woods. You hear a branch snap to your right.\n \n What do you do?");
    optionText("← Follow the path into the woods\n↑ Walk toward the light up the road\n→ Go back in the car and lock the door\n↓ Check the trunk");
  }

  // ==========================================
  // ROOM 3 - THE TRUNK
  // ==========================================

  if (room === 3) {
    (trunkImg) 
      image(trunkImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    
    if (hasFlashlight === false) {
      storyText("You pop the trunk.\n\nUnder the spare tire is your emergency kit. Inside is a FLASHLIGHT 🔦.");
      optionText("↑ Return to the side of the car\n[SPACE] Pick up the Flashlight");
    } else {
      storyText("You click the flashlight on. The light cuts through the dark.\n\nFor a split second, you see eyes shining between the trees.\n\nThen they're gone.");
      optionText("↑ Return to the side of the car");
    }
  }

  // ==========================================
  // ROOM 4 - THE WOODS PATH
  // ==========================================

  if (room === 4) {
    if (hasFlashlight === false) {
      image(pathImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
      storyText("It's so dark you can't see your own hands.\n\nLeaves crunch nearby.");
      optionText("↑ Continue on\n→ Go back to the car");
    } else if (hasFlashlight === true && hasBlessing === false){
      image(pathCabinImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
      storyText("Your flashlight lights up a narrow path between the trees.\n \n Up ahead, you can see the shape of a small cabin.\n\n As you shine the light around you spot a Crucifix on the ground.");
      optionText("↑ Continue on\n→ Go back to the car");
    } else if (hasFlashlight === true && hasBlessing === true){
      image(pathCabinImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
      storyText("Your flashlight lights up a narrow path between the trees.\n \n Up ahead, you can see the shape of a small cabin.");
      optionText("↑ Continue on\n→ Go back to the car");}
}
  // ==========================================
  // ROOM 5 - THE CABIN
  // ==========================================

  if (room === 5) {
   image(cabinImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    if (exorcism === true && hasKey === false) {
      storyText("The cabin is silent now. Whatever was crying is gone.\n\nOn a hook by the far door hangs a KEY.");
      optionText("↓ Head back down the path\n↑ Look in the back room\n [SPACE] Take the Key");
    } else if (exorcism === true && hasKey === true) {
      storyText("The cabin is silent now. Whatever was crying is gone.\n\nThe key is safe in your pocket.");
      optionText("↓ Head back down the path\n↑ Look in the back room");
    } else if (hasKey === false) {
      storyText("The cabin door hangs open and you enter slowly. Embers of a past flame glow in the fireplace.\n\nOn a hook by the far door hangs a KEY. \n\n Sounds of crying can be heard on the other side of the door.");
      optionText("↓ Head back down the path\n↑ Check on the person crying\n [SPACE] Take the Key");
    } else {
      storyText("You slip the key into your pocket.\n\nThe crying grows louder.");
      optionText("↓ Head back down the path\n↑ Check on the person crying");
    }
  }

  // ==========================================
  // ROOM 6 - THE GAS STATION
  // ==========================================

  if (room === 6) {
    background(45, 45, 25);
    if (gasImg) {
      image(gasImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    }
    storyText("You arrive at a run-down gas station. The pumps are rusted as if they haven't been used in years.\n \nBy the garage you spot an old TOW TRUCK. Maybe it still works?\n\nNext to it the door to the office is ajar. Inside, an old man sits behind the counter, rocking in a chair.");
    optionText("↑ Try the tow truck \n ← Go into the office\n↓ Walk back to your car");
  }

  // ==========================================
  // ROOM 11 - THE OFFICE
  // ==========================================
  
  if (room === 11 && hasBlessing === false) {
    image(manImg, 0, 0, 800, 800);
    storyText("You walk into the office and the stench of rot burns your nose. \n \n A creepy old man greets you. A CRUCIFIX ✝️ lays on his desk. \n \n \"Rough night? Have a cup o'joe.\" the old man says, as he offers you a cup of coffee.");
    optionText("↑ Accept the coffee \n ↓ Politely decline and leave \n [SPACE] Pick up the Crucifix")
    }
  else if (room === 11 & hasBlessing === true){
    image(manImg, 0, 0, 800, 800);
    storyText("The old man gives you a suspicous glare. \n \n  \"You the religious type, huh? You can have it, I lost my way years ago.\" \n \n\"Why don't you have some coffee for the road? \" he suggests strongly.");
    optionText("↑ Accept the coffee \n ↓ Politely decline and leave")
  }

  
  // ==========================================
  // ROOM 7 - FINAL (YOU ESCAPED!)
  // ==========================================

  if (room === 7) {
   image(winImg, 0, 0, 800, 800);
    endingText( "The tow truck takes a few tries to start, but eventually roars to life.\n\nThe old man runs out of the garage and tries to chase you.\n\nYou floor it, and don't stop until the woods are far behind you.\n\nYou force yourself to not look in the rearview mirror.", "YOU ESCAPED!", color(60, 200, 60), );
    hintText("(left-click to play again)");
  }
  
  // ==========================================
  // CONDITIONAL ROOMS
  // ==========================================

  // ROOM 10 - Waiting in the car
  if (room === 10) {
    image(carImg, 0, 0, 800, 800);
    storyText("You lock the doors and wait. \n \nYou check your phone again, but still no signal. \n \n You contemplate what to do in frustration.");
     optionText("← Go back outside \n ↓ Doze off")
  }

  // ROOM 12 - Lost in the dark
  if (room === 12) {
    deathScreen("You stumble off the path as the forest gets thicker. The canopy covers any moonlight that would shine below. \n\nYou've fallen into pure darkness and every direction looks the same.\n\n The crunching leaves get louder...no...closer...");
  }

  // ROOM 13 - THE GIRL'S ROOM 
  if (room === 13 && exorcism === true) {
    background(0);
    if (roomEmptyImg) {
      image(roomEmptyImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    }
    storyText("The back room is empty.\n\nThe bed is unmade and the window hangs open. Whatever she was, she's gone.");
    hintText("(left-click to return to the cabin)");
  }
  else if (room === 13) {
    background(0);
    if (roomGirlImg) {
      image(roomGirlImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    }
    storyText("A little girl sits on the bed with her back to you, sobbing.\n\n\"Are you okay?\" you ask.\n\nThe crying turns into laughter. Her head turns in an unnatural way as she crawls upside-down toward you.");
    if (hasBlessing === true) {
      hintText("(left-click to use the Crucifix ✝️)");
    } else {
      hintText("(left-click to continue)");
    }
  }

  // ROOM 14 - THE EMPTY ROOM (you used the Crucifix)
  if (room === 14) {
    background(0);
    if (roomEmptyImg) {
      image(roomEmptyImg, 0, 0, 800, 800);
      fill(0, 0, 0, 75);
      noStroke();
      rect(0, 0, 800, 800);
    }
    storyText("You grab the Crucifix and hold it towards her. She screams in pain and the little girl runs out of the cabin.\n\nThe room is empty now.");
    hintText("(left-click to return to the cabin)");
  }

  // ROOM 15 - Possessed (no Crucifix)
  if (room === 15) {
    deathScreen(possessedImg, "You have nothing to protect yourself.\n\nShe grabs you before you can scream. The door slams shut behind you, and her laughter is the last thing you hear.");
  }

    // ROOM 16 - Drink the coffee
     if (room === 16) {
    deathScreen(manImg, "You take a sip. It's warm, sweet, and comforting.\n \n Minutes pass and your legs go numb. As you fall, he stands up and chuckles.\n\n\"Another one for the woods.\"");
    message = "You got the COFFEE! ☕";
  }
  
    // ROOM 17 - Death in the car
  if (room === 17) {
    deathScreen(carImg, "An hour pass and loud banging on your window wakes you from your slumber. \n \nA frantic woman begs you to let her in.\n\nYou open the door... and her face has turned into a wide smile.");
  }
  
  // ==========================================
  // ALWAYS ON TOP - inventory and messages
  // ==========================================

  if (room >= 2) {
    drawInventory();
  }

  if (message !== "") {
    noStroke();
    fill(0, 0, 0, 190);
    rect(0, 433, 800, 40);
    fill(255, 220, 80);
    textSize(21);
    text(message, 400, 453);
  }
}

// ==========================================
// CLICKING - advances story / restarts
// ==========================================

function mouseClicked() {
  if (room === 0) {
    music.loop();   // starts the music and repeats it forever
    goTo(1);
  }
  else if (room === 1) {
    goTo(2);
  }
    
  else if (room === 13) {
    if (exorcism === true) {
      goTo(5); // girl is already gone, back to the cabin
    }
    else if (hasBlessing === true) {
      exorcism = true; // the girl is driven out for good
      goTo(14); // use the Crucifix
    } else {
      goTo(15); // death: possessed
    }
  }
  else if (room === 14) {
    goTo(5); // back to the cabin
  }
  else if (room === 7 || room === 17 || room === 12 || room === 16) {
    restartGame();
  }
}

// ==========================================
// KEYS - arrow keys choose, space picks up
// ==========================================

function keyPressed() {

  // ROOM 2 - The Car
  if (room === 2) {
    if (key === 'ArrowLeft') {
      goTo(4);
    }
    else if (key === 'ArrowUp') {
      goTo(6);
    }
    else if (key === 'ArrowRight') {
      goTo(10);
    }
    else if (key === 'ArrowDown') {
      goTo(3); // death: waiting
    }
  }

  // ROOM 3 - The Trunk
  else if (room === 3) {
    if (key === ' ' && hasFlashlight === false) {
      hasFlashlight = true;
      message = "You got the FLASHLIGHT! 🔦";
    }
    else if (key === 'ArrowUp') {
      goTo(2);
    }
  }

  // ROOM 4 - The Woods Path
  else if (room === 4) {
    if (key === 'ArrowUp') {
      if (hasFlashlight === true) {
        goTo(5);
      } else {
        goTo(12); // death: lost in the dark
      }
    }
    else if (key === 'ArrowRight') {
      goTo(2);
    }
  }

  // ROOM 5 - The Cabin
  else if (room === 5) {
    if (key === ' ' && hasKey === false) {
      hasKey = true;
      message = "You got the KEY! 🔑";
    }
    else if (key === 'ArrowDown') {
      goTo(4);
    }
    else if  (key === 'ArrowUp') {
      goTo(13); // little girl
    }
  }

  // ROOM 6 - The Gas Station
  else if (room === 6) {
    if (key === 'ArrowUp') {
      if (hasKey === true) {
        goTo(7); // you win!
      } else {
        message = "The truck is locked. You need a key.";
      }
    }
    else if (key === 'ArrowLeft') {
      goTo(11);
    }
    else if (key === 'ArrowDown') {
      goTo(2);
    }
  }

 // ROOM 10 - The car
  else if (room === 10) {
    if (key === 'ArrowLeft') {
      goTo(2);
    }
    else if (key === 'ArrowDown'){
      goTo(17)
    }
    else if (key === 'ArrowUp' && hasCoffee === false){
      hasCoffee = true;
        goTo(16); // you died
    }
    else if (key === 'ArrowDown'){
      goTo(6);
     }
  }
    
    // ROOM 11 - The office
  else if (room === 11) {
    if (key === ' ' && hasBlessing === false) {
      hasBlessing = true;
      message = "You got the Crucifix ✝️";
    }
    else if (key === 'ArrowUp' && hasCoffee === false){
      hasCoffee = true;
        goTo(16); // you died
    }
    else if (key === 'ArrowDown'){
      goTo(6);
     }
  }
}
// ==========================================
// ADDITIONAL FUNCTIONS
// ==========================================

// Changes rooms and clears any old message
function goTo(newRoom) {
  let oldRoom = room;
  room = newRoom;
  message = "";

//Additional Sounds
  if (room === 7 ) {
    winSound.play(); 
  }
  
  if ((oldRoom === 5 || oldRoom === 13) && newRoom !== 13) {
    cryingSound.stop();
  }
  if (newRoom === 5 && oldRoom === 4 && exorcism === false) {
    cryingSound.loop();
  }
  if (newRoom === 13 && exorcism === false) {
    cryingSound.loop(); 
  }

  // Dead sound: every death room
  if (newRoom === 17 || newRoom === 12 || newRoom === 15 || newRoom === 16) {
    deadSound.play();
  }

  // Laugh: the possessed girl
  if (newRoom === 15) {
    laughSound.play();
  }
  // Laugh: the creepy man
  if (newRoom === 16) {
    laugh2Sound.play();
  }
}

// Resets everything for a new game
function restartGame() {
  hasFlashlight = false;
  hasKey = false;
  hasBlessing = false;
  hasCoffee = false;
  exorcism = false;
  goTo(0);
}

// TextPanel
function textPanel() {
  noStroke();
  fill(0, 0, 0, 100);
  rect(0, 500, 800, 320);
}

// Main story text
function storyText(words) {
  textPanel();
  fill(230);
  textSize(16);
  textLeading(24);
  textAlign(CENTER, TOP);
  text(words, 40, 533, 720, 180);
  textAlign(CENTER, CENTER);
}

// Choices 
function optionText(words) {
  fill(200, 200, 120);
  textSize(13);
  textLeading(23);
  textAlign(CENTER, TOP);
  text(words, 40, 683, 720, 113);
  textAlign(CENTER, CENTER);
}

// Small gray hint at the bottom
function hintText(words) {
  fill(120);
  textSize(17);
  text(words, 400, 784);
}

// Title + story in the bottom box 
function endingText(words, title, titleColor) {
  textPanel();
  fill(230);
  textSize(19);
  textLeading(23);
  textAlign(CENTER, TOP);
  text(words, 40, 533, 720, 220);
  textAlign(CENTER, CENTER) 
  fill(titleColor);
  textSize(40);
  text(title, 400, 733);;
}

// Shows what you're carrying in the top-left corner
function drawInventory() {
  fill(0);
  rect(0, 0, 800, 40);
  textAlign(LEFT, TOP);
  fill(160);
  textSize(19);
  let items = "Inventory: ";
  if (hasFlashlight === false && hasKey === false && hasBlessing === false && hasCoffee === false) {
    items = items + "empty";
  }
  if (hasFlashlight === true) {
    items = items + "🔦";
  }
  if (hasKey === true) {
    items = items + "🔑";
  }
  if (hasBlessing === true) {
    items = items + "✝️";
  }
    if (hasCoffee === true) {
    items = items + "☕";
  }
  text(items, 13, 13);
  textAlign(CENTER, CENTER);
}

// Red "game over" screen
function deathScreen(img, words) {
  if (words === undefined) {
    words = img;
    img = undefined;
  }
  background(70, 0, 0);
  if (img) {
    image(img, 0, 0, 800, 800);
    fill(70, 0, 0, 100);
    noStroke();
    rect(0, 0, 800, 800);
  }
  textPanel();
  fill(230);
  textSize(19);
  textLeading(23);
  textAlign(CENTER, TOP);
  text(words, 40, 520, 720, 187);
  textAlign(CENTER, CENTER);
  fill(255, 60, 60);
  textSize(40);
  text("YOU DIED", 400, 725);
  hintText("(left-click to try again)");
}